def prt() :
    print('hello')
